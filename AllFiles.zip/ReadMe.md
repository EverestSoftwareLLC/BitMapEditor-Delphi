Bitmap Editor

This is code for a single form, simple, bitmap editor for Delphi.  I used Delphi 10.2.3. 
The only files required are:
BitMapEditorDialog.pas
BitMapEditorDialog.dfm
BitmapEditor.res
BMCursor.res
RotateBitmapUnit.pas

All the other files are for an example project.

